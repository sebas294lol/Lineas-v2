# Trayectoria de Tiros v2
App Android independiente y ligera.

Menu: Normal / Retos / Modo Portero.
Normal y Retos: objetivo tocable, curva y potencia ajustables, trayectoria visible y mini jugador pixel-art pateando.
Portero: Fácil / Medio / Difícil, tiros variados, atajadas, goles y porcentaje.

Compilación: GitHub Actions -> Build APK.
